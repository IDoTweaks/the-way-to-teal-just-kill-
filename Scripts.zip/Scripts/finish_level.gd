extends Control
var score = 0;
var targScore = 0
var upEach :float = 0
@onready var scoreShow = $UI/MainContainer/title/ScoreShow
@onready var ui = $UI
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func _setScore(newScore:int):
	targScore = newScore
	upEach = newScore / 2.5
func _setGrade(newGrade: String):
	$UI/MainContainer/title/gradeShow.text = "GRADE: %s" % newGrade

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if self.visible == false:
		ui.visible = false
	else:
		ui.visible = true
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		print(ui.visible)
		_forceVisible(ui)
	if targScore > score:
		score += upEach * delta
		scoreShow.text = "SCORE: \n%d" % int(score)

func _forceVisible(entity):
	if entity.get_children().size() > 0:
		var children = entity.get_children()
		for child in children:
			_forceVisible(child)
	if entity is CanvasItem:
		entity.visible = true
	


func _on_quit_btn_button_down() -> void:
	get_tree().quit(6967)


func _on_retry_button_down() -> void:
	get_tree().change_scene_to_packed(Global.levels[1])
