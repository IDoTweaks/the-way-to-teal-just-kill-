extends CharacterBody3D


const SPEED = 7.5
const JUMP_VELOCITY = 4.5
@onready var attackTimer = $attackCd
@onready var animPlayer = $AnimationPlayer

@export var scoreWorth = 5000
@export var health = 100
@onready var body =$body
@onready var explosionParticles = preload("res://Particles/enemyExplode.tscn")
var particleInstance
@export var navAgent : NavigationAgent3D
@export var damage = 5
@export var accelaration = 10
var target
var mode : String = "idle"
var gotShot = false
var shouldMove = false
var canAttack : bool = true

func _makeTarg(targ):
	gotShot = true
	target = targ

func _ready() -> void:
	body._updateMat(1)
	await get_tree().physics_frame

func _damage(dmg):
	health -= dmg
	if health >= 0:
		body._updateMat(health / 100)
	else:
		_die()
		
func _die():
	body._updateMat(0)
	particleInstance = explosionParticles.instantiate()
	particleInstance.position = global_position
	get_parent().add_child(particleInstance)
	particleInstance.emitting = true
	queue_free()


func _physics_process(delta: float) -> void:
	if mode == "attack" and canAttack and target != null:
		animPlayer.play("attack")
		canAttack = false
		attackTimer.start()
		target._takeDamage(damage)
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		
	if mode != "attack":
		var space = get_world_3d().direct_space_state
		var horizontal = Vector3(velocity.x,0,velocity.z).normalized()
		if horizontal.length() > 0.1:
			var ray = PhysicsRayQueryParameters3D.create(global_position + horizontal * .6, global_position + horizontal * .6 + Vector3(0,-2,0))
			ray.exclude = [self.get_rid()]
			var hit = space.intersect_ray(ray)
			if !hit:
				velocity.x = 0
				velocity.z = 0
	#if shouldMove:
	move_and_slide()


func _on_attack_body_entered(body: Node3D) -> void:
	if not gotShot:
		if body.has_method("player"):
			mode = "attack"
		if target == null:
			target = body


func _on_attack_body_exited(body: Node3D) -> void:
	if not gotShot:
		if body.has_method("player"):
			mode = "chase"


func _on_chase_body_entered(body: Node3D) -> void:
	if not gotShot:
		if body.has_method("player"):
			target = body
			mode = "chase"


func _on_attack_cd_timeout() -> void:
	canAttack = true
